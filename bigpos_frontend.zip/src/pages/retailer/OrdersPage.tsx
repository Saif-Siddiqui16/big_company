import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Table,
  Space,
  Card,
  Typography,
  Descriptions,
  Button,
  Tag,
  Steps,
  Row,
  Col,
  Input,
  Select,
  Modal,
  message,
  Spin,
  Statistic,
  Timeline,
  Empty,
  Form,
  Badge,
} from 'antd';
import {
  SearchOutlined,
  ReloadOutlined,
  EyeOutlined,
  CheckOutlined,
  CloseOutlined,
  PrinterOutlined,
  TruckOutlined,
  ShoppingCartOutlined,
  DollarOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined,
} from '@ant-design/icons';
import { retailerApi } from '../../services/apiService';
import { printThermalReceipt } from '../../utils/receiptPrinter';

const { Title, Text } = Typography;

interface OrderItem {
  id: string;
  product_id: string;
  product_name: string;
  sku: string;
  quantity: number;
  unit_price: number;
  total: number;
  image?: string;
}

interface Order {
  id: string;
  display_id: string;
  customer_name: string;
  customer_phone: string;
  customer_email?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  total: number;
  status: 'draft' | 'awaiting_payment' | 'pending' | 'pending_payment' | 'confirmed' | 'processing' | 'shipped' | 'ready' | 'completed' | 'delivered' | 'cancelled';
  payment_method: 'dashboard_wallet' | 'credit_wallet' | 'mobile_money' | 'cash' | 'wallet' | 'nfc' | 'credit';
  payment_status: 'pending' | 'paid' | 'refunded';
  notes?: string;
  created_at: string;
  updated_at: string;
  completed_at?: string;
  cancelled_at?: string;
  cancel_reason?: string;
  rejection_reason?: string;
  cancellation_reason?: string;
  shipperName?: string;
  shipperPhone?: string;
  vehiclePlate?: string;
}

interface OrderStats {
  // Status counts
  pending: number;
  processing: number;
  shipped: number;
  ready: number;
  completed_today: number;
  cancelled_today: number;
  // Revenue by payment method
  total_online_revenue: number;
  dashboard_wallet_revenue: number;
  credit_wallet_revenue: number;
  mobile_money_revenue: number;
  gas_rewards_m3: number;
  gas_rewards_rwf: number;
}

const statusColors: Record<string, string> = {
  draft: 'default',
  awaiting_payment: 'warning',
  pending_payment: 'orange',
  pending: 'orange',
  confirmed: 'cyan',
  processing: 'cyan',
  shipped: 'purple',
  ready: 'blue',
  completed: 'green',
  delivered: 'green',
  cancelled: 'red',
};

const statusLabels: Record<string, string> = {
  draft: 'USSD CALLBACK',
  awaiting_payment: 'AWAITING PAYMENT',
  pending_payment: 'PENDING PAYMENT',
  pending: 'PENDING',
  confirmed: 'PROCEED',
  processing: 'PROCEED',
  shipped: 'SHIPPED',
  completed: 'DELIVERED',
  delivered: 'DELIVERED',
  cancelled: 'CANCELLED',
};

const paymentColors: Record<string, string> = {
  dashboard_wallet: 'blue',
  credit_wallet: 'purple',
  mobile_money: 'gold',
  cash: 'green',
  wallet: 'blue',
  nfc: 'purple',
  credit: 'orange',
};

const paymentLabels: Record<string, string> = {
  dashboard_wallet: 'Dashboard Wallet',
  credit_wallet: 'Credit Wallet',
  mobile_money: 'Mobile Money',
  cash: 'Cash',
  wallet: 'Wallet',
  nfc: 'NFC Card',
  credit: 'Credit',
};

export const OrdersPage = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<OrderStats | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [paymentFilter, setPaymentFilter] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [pagination, setPagination] = useState({ current: 1, pageSize: 20, total: 0 });

  // Action modal
  const [actionModal, setActionModal] = useState<{
    visible: boolean;
    order: Order | null;
    action: 'accept' | 'reject' | 'ready' | 'complete' | 'cancel' | 'ship' | null;
  }>({ visible: false, order: null, action: null });
  const [actionLoading, setActionLoading] = useState(false);
  const [actionNotes, setActionNotes] = useState('');
  const [shipperName, setShipperName] = useState('');
  const [shipperPhone, setShipperPhone] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');

  // View modal
  const [viewModal, setViewModal] = useState<{ visible: boolean; order: Order | null }>({
    visible: false,
    order: null,
  });
  const [viewLoading, setViewLoading] = useState(false);

  // Configure Modal state
  const [configureModalVisible, setConfigureModalVisible] = useState(false);
  const [selectedConfigureOrder, setSelectedConfigureOrder] = useState<Order | null>(null);
  const [inventoryProducts, setInventoryProducts] = useState<any[]>([]);
  const [configureLoading, setConfigureLoading] = useState(false);
  const [selectedItems, setSelectedItems] = useState<Array<{ productId: string; quantity: number }>>([]);
  const [rewardWalletId, setRewardWalletId] = useState<string>('');

  const handleOpenConfigureModal = async (order: Order) => {
    setSelectedConfigureOrder(order);
    setSelectedItems([]);
    setRewardWalletId('');
    setConfigureModalVisible(true);
    setConfigureLoading(true);
    try {
      const response = await retailerApi.getInventory();
      const products = response.data.products || response.data || [];
      setInventoryProducts(products);
    } catch (err) {
      console.error('Failed to load inventory:', err);
      message.error('Failed to load inventory products');
    } finally {
      setConfigureLoading(false);
    }
  };

  const handleAddItemToConfigure = (productId: any) => {
    setSelectedItems((prev) => {
      const exists = prev.find((item) => String(item.productId) === String(productId));
      if (exists) {
        return prev.map((item) =>
          String(item.productId) === String(productId) ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { productId: String(productId), quantity: 1 }];
    });
  };

  const handleUpdateItemQuantity = (productId: any, quantity: number) => {
    if (quantity <= 0) {
      setSelectedItems((prev) => prev.filter((item) => String(item.productId) !== String(productId)));
      return;
    }
    setSelectedItems((prev) =>
      prev.map((item) => (String(item.productId) === String(productId) ? { ...item, quantity } : item))
    );
  };

  const handleSubmitConfiguration = async () => {
    if (!selectedConfigureOrder) return;
    if (selectedItems.length === 0) {
      message.error('Please add at least one product to the order.');
      return;
    }
    setConfigureLoading(true);
    try {
      await retailerApi.configureOrder(selectedConfigureOrder.id, selectedItems, rewardWalletId.trim() || undefined);
      message.success('Order configured successfully and requested payment');
      setConfigureModalVisible(false);
      loadOrders();
    } catch (err) {
      console.error('Failed to configure order:', err);
      message.error('Failed to configure order');
    } finally {
      setConfigureLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
    const interval = setInterval(() => loadOrders(true), 15000);
    return () => clearInterval(interval);
  }, [statusFilter, paymentFilter, pagination.current]);

  const loadOrders = async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);

    try {
      const response = await retailerApi.getOrders({
        status: statusFilter || undefined,
        payment_status: paymentFilter || undefined,
        search: searchTerm || undefined,
        limit: pagination.pageSize,
        offset: (pagination.current - 1) * pagination.pageSize,
      });

      const data = response.data;
      setOrders(data.orders || []);
      setPagination((prev) => ({ ...prev, total: data.total || 0 }));

      const allOrders = data.orders || [];
      const completedOrders = allOrders.filter((o: Order) => o.status === 'completed' || o.status === 'delivered');

      // Fetch actual stats from backend dashboard stats to get correct overall totals
      let dashboardWalletRevenue = 0;
      let creditWalletRevenue = 0;
      let mobileMoneyRevenue = 0;
      let totalOnlineRevenue = 0;

      try {
        const dashboardStatsResponse = await retailerApi.getDashboardStats();
        if (dashboardStatsResponse.data && dashboardStatsResponse.data.stats) {
          const ds = dashboardStatsResponse.data.stats;
          dashboardWalletRevenue = ds.dashboardWalletRevenue || 0;
          creditWalletRevenue = ds.creditWalletRevenue || 0;
          mobileMoneyRevenue = ds.mobileMoneyRevenue || 0;
          totalOnlineRevenue = dashboardWalletRevenue + creditWalletRevenue + mobileMoneyRevenue;
        }
      } catch (err) {
        console.error('Failed to load dashboard stats:', err);
      }

      // Fetch actual gas rewards from backend
      let gasRewardsM3 = 0;
      let gasRewardsRwf = 0;
      try {
        const gasRewardsResponse = await retailerApi.getGasRewards();
        if (gasRewardsResponse.data && gasRewardsResponse.data.stats) {
          gasRewardsM3 = gasRewardsResponse.data.stats.totalM3 || 0;
          gasRewardsRwf = gasRewardsResponse.data.stats.totalValue || 0;
        }
      } catch (err) {
        console.error('Failed to load real gas rewards:', err);
      }

      setStats({
        pending: allOrders.filter((o: Order) => o.status === 'pending' || o.status === 'pending_payment').length,
        processing: allOrders.filter((o: Order) => o.status === 'processing' || o.status === 'confirmed').length,
        shipped: allOrders.filter((o: Order) => o.status === 'shipped').length,
        ready: allOrders.filter((o: Order) => o.status === 'ready').length,
        completed_today: completedOrders.length,
        cancelled_today: allOrders.filter((o: Order) => o.status === 'cancelled').length,
        total_online_revenue: totalOnlineRevenue,
        dashboard_wallet_revenue: dashboardWalletRevenue,
        credit_wallet_revenue: creditWalletRevenue,
        mobile_money_revenue: mobileMoneyRevenue,
        gas_rewards_m3: gasRewardsM3,
        gas_rewards_rwf: gasRewardsRwf,
      });
    } catch (error) {
      console.error('Failed to load orders:', error);
      message.error('Failed to load orders');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadOrderDetail = async (orderId: string) => {
    setViewLoading(true);
    try {
      const response = await retailerApi.getOrder(orderId);
      const order = response.data.order || response.data;
      setViewModal({ visible: true, order });
    } catch (error) {
      console.error('Failed to load order:', error);
      message.error('Failed to load order details');
    } finally {
      setViewLoading(false);
    }
  };

  const handleAction = async () => {
    if (!actionModal.order || !actionModal.action) return;

    setActionLoading(true);
    try {
      const { order, action } = actionModal;

      switch (action) {
        case 'accept':
          await retailerApi.updateOrderStatus(order.id, 'processing', { notes: actionNotes });
          message.success('Order accepted');
          break;
        case 'reject':
        case 'cancel':
          if (!actionNotes.trim()) {
            message.error('Please provide a reason');
            setActionLoading(false);
            return;
          }
          await retailerApi.cancelOrder(order.id, actionNotes);
          message.success('Order cancelled');
          break;
        case 'ready':
          await retailerApi.updateOrderStatus(order.id, 'ready', { notes: actionNotes });
          message.success('Order marked as ready');
          break;
        case 'ship':
          if (!shipperName || !shipperPhone || !vehiclePlate) {
            message.error('Please provide all shipper details');
            setActionLoading(false);
            return;
          }
          await retailerApi.updateOrderStatus(order.id, 'shipped', {
            shipperName: shipperName,
            shipperPhone: shipperPhone,
            vehiclePlate: vehiclePlate,
            notes: actionNotes
          });
          message.success('Order marked as shipped');
          break;
        case 'complete':
          await retailerApi.fulfillOrder(order.id);
          message.success('Order completed');
          break;
      }

      setActionModal({ visible: false, order: null, action: null });
      setActionNotes('');
      loadOrders();
    } catch (error: any) {
      message.error(error.response?.data?.error || 'Action failed');
    } finally {
      setActionLoading(false);
    }
  };

  const getActionTitle = () => {
    switch (actionModal.action) {
      case 'accept': return 'Accept Order';
      case 'reject': return 'Reject Order';
      case 'ready': return 'Mark as Ready';
      case 'ship': return 'Ship Order';
      case 'complete': return 'Complete Order';
      case 'cancel': return 'Cancel Order';
      default: return 'Order Action';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-RW', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)}h ago`;
    return formatDate(dateString);
  };

  const columns = [
    {
      title: 'Order #',
      dataIndex: 'display_id',
      key: 'display_id',
      render: (value: string, record: Order) => (
        <Button type="link" onClick={() => loadOrderDetail(record.id)}>
          <Text strong>#{value || record.id.slice(0, 8)}</Text>
        </Button>
      ),
    },
    {
      title: 'Customer',
      dataIndex: 'customer_name',
      key: 'customer_name',
      render: (name: string, record: Order) => (
        <div>
          <Text strong>{name}</Text>
          <br />
          <Text type="secondary" style={{ fontSize: '12px' }}>{record.customer_phone}</Text>
        </div>
      ),
    },
    {
      title: 'Items',
      key: 'items',
      render: (_: any, record: Order) => (
        <Badge count={record.items?.length || 0} showZero>
          <ShoppingCartOutlined style={{ fontSize: 18 }} />
        </Badge>
      ),
    },
    {
      title: 'Total',
      dataIndex: 'total',
      key: 'total',
      render: (value: number) => (
        <Text strong style={{ color: '#0ea5e9' }}>{value?.toLocaleString()} RWF</Text>
      ),
      sorter: (a: Order, b: Order) => a.total - b.total,
    },
    {
      title: 'Payment',
      dataIndex: 'payment_method',
      key: 'payment_method',
      render: (value: string) => (
        <Tag color={paymentColors[value] || 'default'}>
          {paymentLabels[value] || value?.toUpperCase()}
        </Tag>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (value: string) => (
        <Tag color={statusColors[value] || 'default'}>
          {statusLabels[value] || value?.toUpperCase()}
        </Tag>
      ),
    },
    {
      title: 'Time',
      dataIndex: 'created_at',
      key: 'created_at',
      render: (value: string) => <Text>{getRelativeTime(value)}</Text>,
      sorter: (a: Order, b: Order) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: Order) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => loadOrderDetail(record.id)}
          />
          {record.status === 'draft' && (
            <Button
              type="primary"
              size="small"
              icon={<ShoppingCartOutlined />}
              onClick={() => handleOpenConfigureModal(record)}
            >
              Configure Order
            </Button>
          )}
          {record.status === 'pending' && (
            <>
              <Button
                type="primary"
                size="small"
                icon={<CheckOutlined />}
                onClick={() => setActionModal({ visible: true, order: record, action: 'accept' })}
              >
                Accept
              </Button>
              <Button
                danger
                size="small"
                icon={<CloseOutlined />}
                onClick={() => setActionModal({ visible: true, order: record, action: 'reject' })}
              >
                Reject
              </Button>
            </>
          )}
          {(record.status === 'processing' || record.status === 'confirmed') && (
            <Space>
              <Button
                type="primary"
                size="small"
                icon={<TruckOutlined />}
                onClick={() => setActionModal({ visible: true, order: record, action: 'ship' })}
              >
                Ship
              </Button>
              <Button
                size="small"
                onClick={() => setActionModal({ visible: true, order: record, action: 'ready' })}
              >
                Ready
              </Button>
            </Space>
          )}
          {record.status === 'shipped' && (
            <Tag color="purple">IN TRANSIT</Tag>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div style={{ padding: '16px' }}>
      <Row justify="space-between" align="middle" style={{ marginBottom: 24 }}>
        <Title level={3} style={{ margin: 0 }}>Orders</Title>
        <Button
          icon={<ReloadOutlined spin={refreshing} />}
          onClick={() => loadOrders(true)}
          loading={refreshing}
        >
          Refresh
        </Button>
      </Row>

      {/* Revenue Stats Cards */}
      {stats && (
        <>
          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col xs={24} sm={12} md={5}>
              <Card size="small" style={{ background: 'linear-gradient(135deg, #52c41a 0%, #73d13d 100%)', border: 'none' }}>
                <Statistic
                  title={<span style={{ color: 'rgba(255,255,255,0.9)' }}>Total Online Revenue</span>}
                  value={stats.total_online_revenue}
                  suffix="RWF"
                  valueStyle={{ color: 'white', fontSize: '18px' }}
                  formatter={(value) => value?.toLocaleString()}
                />
              </Card>
            </Col>
            <Col xs={12} sm={12} md={5}>
              <Card size="small">
                <Statistic
                  title="Dashboard Wallet Revenue"
                  value={stats.dashboard_wallet_revenue}
                  suffix="RWF"
                  valueStyle={{ color: '#1890ff', fontSize: '16px' }}
                  formatter={(value) => value?.toLocaleString()}
                />
              </Card>
            </Col>
            <Col xs={12} sm={12} md={5}>
              <Card size="small">
                <Statistic
                  title="Credit Wallet Revenue"
                  value={stats.credit_wallet_revenue}
                  suffix="RWF"
                  valueStyle={{ color: '#722ed1', fontSize: '16px' }}
                  formatter={(value) => value?.toLocaleString()}
                />
              </Card>
            </Col>
            <Col xs={12} sm={12} md={5}>
              <Card size="small">
                <Statistic
                  title="Mobile Money Revenue"
                  value={stats.mobile_money_revenue}
                  suffix="RWF"
                  valueStyle={{ color: '#faad14', fontSize: '16px' }}
                  formatter={(value) => value?.toLocaleString()}
                />
              </Card>
            </Col>
            <Col xs={12} sm={12} md={4}>
              <Card size="small" style={{ background: '#fff7e6', borderColor: '#ffc069' }}>
                <Statistic
                  title="Gas Rewards Given"
                  value={stats.gas_rewards_m3.toFixed(4)}
                  suffix={<span>M³ <Text type="secondary" style={{ fontSize: 11 }}>({stats.gas_rewards_rwf.toLocaleString()} RWF)</Text></span>}
                  valueStyle={{ color: '#fa541c', fontSize: '16px' }}
                />
              </Card>
            </Col>
          </Row>

          {/* Order Status Counts */}
          <Card size="small" style={{ marginBottom: 16 }}>
            <Row gutter={16} align="middle">
              <Col>
                <Text strong style={{ marginRight: 16 }}>Order Status:</Text>
              </Col>
              <Col>
                <Space size="large">
                  <Badge count={stats.pending} showZero overflowCount={999}>
                    <Tag color="orange" style={{ marginRight: 0 }}>Pending</Tag>
                  </Badge>
                  <Badge count={stats.processing} showZero overflowCount={999}>
                    <Tag color="cyan" style={{ marginRight: 0 }}>Proceed</Tag>
                  </Badge>
                  <Badge count={stats.shipped} showZero overflowCount={999}>
                    <Tag color="purple" style={{ marginRight: 0 }}>Shipped</Tag>
                  </Badge>
                  <Badge count={stats.ready} showZero overflowCount={999}>
                    <Tag color="blue" style={{ marginRight: 0 }}>Ready</Tag>
                  </Badge>
                  <Badge count={stats.completed_today} showZero overflowCount={999}>
                    <Tag color="green" style={{ marginRight: 0 }}>Completed</Tag>
                  </Badge>
                  <Badge count={stats.cancelled_today} showZero overflowCount={999}>
                    <Tag color="red" style={{ marginRight: 0 }}>Cancelled</Tag>
                  </Badge>
                </Space>
              </Col>
            </Row>
          </Card>
        </>
      )}

      {/* Filters */}
      <Card size="small" style={{ marginBottom: 16 }}>
        <Row gutter={16}>
          <Col xs={24} sm={12} md={6}>
            <Input.Search
              placeholder="Search orders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onSearch={() => loadOrders()}
              prefix={<SearchOutlined />}
              allowClear
            />
          </Col>
          <Col xs={12} sm={6} md={4}>
            <Select
              placeholder="Status"
              value={statusFilter}
              onChange={setStatusFilter}
              style={{ width: '100%' }}
              allowClear
            >
              <Select.Option value="">All Status</Select.Option>
              <Select.Option value="draft">USSD Callbacks</Select.Option>
              <Select.Option value="awaiting_payment">Awaiting Payment</Select.Option>
              <Select.Option value="pending">Pending</Select.Option>
              <Select.Option value="confirmed">Confirmed</Select.Option>
              <Select.Option value="processing">Processing</Select.Option>
              <Select.Option value="shipped">Shipped</Select.Option>
              <Select.Option value="ready">Ready</Select.Option>
              <Select.Option value="completed">Completed</Select.Option>
              <Select.Option value="cancelled">Cancelled</Select.Option>
            </Select>
          </Col>
          <Col xs={12} sm={6} md={4}>
            <Select
              placeholder="Payment Method"
              value={paymentFilter}
              onChange={setPaymentFilter}
              style={{ width: '100%' }}
              allowClear
            >
              <Select.Option value="">All Payments</Select.Option>
              <Select.Option value="dashboard_wallet">Dashboard Wallet</Select.Option>
              <Select.Option value="credit_wallet">Credit Wallet</Select.Option>
              <Select.Option value="momo">MTN Mobile Money</Select.Option>
                          <Select.Option value="airtel">Airtel Money</Select.Option>
            </Select>
          </Col>
        </Row>
      </Card>

      {/* Orders Table */}
      <Card>
        <Table
          dataSource={orders}
          columns={columns}
          rowKey="id"
          loading={loading}
          scroll={{ x: 900 }}
          size="small"
          pagination={{
            ...pagination,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `Total ${total} orders`,
            size: 'small',
            onChange: (page, pageSize) => setPagination({ ...pagination, current: page, pageSize }),
          }}
          rowClassName={(record) =>
            record.status === 'pending' ? 'ant-table-row-pending' : ''
          }
        />
      </Card>

      {/* Action Modal */}
      <Modal
        title={getActionTitle()}
        open={actionModal.visible}
        onCancel={() => {
          setActionNotes('');
          setShipperName('');
          setShipperPhone('');
          setVehiclePlate('');
          setActionModal({ visible: false, order: null, action: null });
        }}
        onOk={handleAction}
        confirmLoading={actionLoading}
        okText={actionModal.action === 'reject' || actionModal.action === 'cancel' ? 'Confirm Cancel' : 'Confirm'}
        okButtonProps={{
          danger: actionModal.action === 'reject' || actionModal.action === 'cancel',
        }}
      >
        {actionModal.order && (
          <div>
            <Descriptions column={1} size="small" style={{ marginBottom: 16 }}>
              <Descriptions.Item label="Order">
                #{actionModal.order.display_id || actionModal.order.id.slice(0, 8)}
              </Descriptions.Item>
              <Descriptions.Item label="Customer">
                {actionModal.order.customer_name}
              </Descriptions.Item>
              <Descriptions.Item label="Total">
                <Text strong>{actionModal.order.total?.toLocaleString()} RWF</Text>
              </Descriptions.Item>
            </Descriptions>

            {(actionModal.action === 'reject' || actionModal.action === 'cancel') && (
              <Form.Item label="Reason" required style={{ marginBottom: 0 }}>
                <Input.TextArea
                  value={actionNotes}
                  onChange={(e) => setActionNotes(e.target.value)}
                  placeholder="Enter reason for cancellation..."
                  rows={3}
                />
              </Form.Item>
            )}

            {(actionModal.action === 'accept' || actionModal.action === 'ready' || actionModal.action === 'ship') && (
              <Form.Item label="Notes (optional)" style={{ marginBottom: 16 }}>
                <Input.TextArea
                  value={actionNotes}
                  onChange={(e) => setActionNotes(e.target.value)}
                  placeholder="Add notes..."
                  rows={2}
                />
              </Form.Item>
            )}

            {actionModal.action === 'ship' && (
              <Space direction="vertical" style={{ width: '100%' }}>
                <Form.Item label="Shipper Name" required>
                  <Input
                    value={shipperName}
                    onChange={(e) => setShipperName(e.target.value)}
                    placeholder="Enter driver/shipper name"
                  />
                </Form.Item>
                <Form.Item label="Shipper Phone" required>
                  <Input
                    value={shipperPhone}
                    onChange={(e) => setShipperPhone(e.target.value)}
                    placeholder="Enter phone number"
                  />
                </Form.Item>
                <Form.Item label="Vehicle Plate Number" required>
                  <Input
                    value={vehiclePlate}
                    onChange={(e) => setVehiclePlate(e.target.value)}
                    placeholder="Enter plate number (e.g. RAD 123 A)"
                  />
                </Form.Item>
              </Space>
            )}
          </div>
        )}
      </Modal>

      {/* View Order Modal */}
      <Modal
        title={`Order #${viewModal.order?.display_id || viewModal.order?.id?.slice(0, 8) || ''}`}
        open={viewModal.visible}
        onCancel={() => setViewModal({ visible: false, order: null })}
        footer={[          <Button key="print" type="primary" icon={<PrinterOutlined />} onClick={() => {
            if (!viewModal.order) return;
            const order = viewModal.order;
            printThermalReceipt({
              receiptNo: '#' + (order.display_id || order.id?.substring(0, 8)),
              date: order.created_at || new Date(),
              paymentMethod: (order.payment_method || 'CASH').toUpperCase(),
              customerName: order.customer_name,
              customerPhone: order.customer_phone,
              items: (order.items || []).map((item: any) => ({
                name: item.product_name || item.name || 'Product',
                quantity: item.quantity,
                unitPrice: item.unit_price || item.price,
                total: item.total || (item.unit_price * item.quantity),
                sku: item.sku,
              })),
              subtotal: order.subtotal || order.total,
              tax: order.tax || Math.round((order.total * 0.18) / 1.18),
              discount: order.discount,
              total: order.total,
              receiptTitle: 'OFFICIAL SALES RECEIPT',
            }, { autoPrint: true });
          }}>
            Print Receipt
          </Button>,
          <Button key="close" onClick={() => setViewModal({ visible: false, order: null })}>
            Close
          </Button>,
        ]}
        width={700}
      >
        {viewLoading ? (
          <div style={{ textAlign: 'center', padding: 40 }}><Spin /></div>
        ) : viewModal.order ? (
          <div>
            {/* Status Steps */}
            {viewModal.order.status !== 'cancelled' && (
              <Steps
                current={['pending', 'processing', 'shipped', 'completed'].indexOf(viewModal.order.status)}
                size="small"
                style={{ marginBottom: 24 }}
                items={[
                  { title: 'Pending' },
                  { title: 'Proceed' },
                  { title: 'Shipped' },
                  { title: 'Delivered' },
                ]}
                className="no-print"
              />
            )}

            {viewModal.order.status === 'cancelled' && (
              <div style={{ background: '#fff1f0', padding: 16, borderRadius: 8, marginBottom: 24 }}>
                <ExclamationCircleOutlined style={{ color: '#ff4d4f', marginRight: 8 }} />
                <Text strong style={{ color: '#ff4d4f' }}>Order Cancelled</Text>
                {(viewModal.order.rejection_reason || viewModal.order.cancellation_reason || viewModal.order.cancel_reason) && (
                  <div><Text type="secondary">Reason: {viewModal.order.rejection_reason || viewModal.order.cancellation_reason || viewModal.order.cancel_reason}</Text></div>
                )}
              </div>
            )}

            {viewModal.order.shipperName && (
              <div style={{ background: '#f9f0ff', padding: 16, borderRadius: 8, marginBottom: 24, border: '1px solid #d3adf7' }}>
                <TruckOutlined style={{ color: '#722ed1', marginRight: 8 }} />
                <Text strong style={{ color: '#722ed1' }}>Shipping Information</Text>
                <Descriptions size="small" column={2} style={{ marginTop: 8 }}>
                  <Descriptions.Item label="Shipper">{viewModal.order.shipperName}</Descriptions.Item>
                  <Descriptions.Item label="Phone">{viewModal.order.shipperPhone}</Descriptions.Item>
                  <Descriptions.Item label="Vehicle Plate">{viewModal.order.vehiclePlate}</Descriptions.Item>
                </Descriptions>
              </div>
            )}

            <Descriptions column={2} size="small" style={{ marginBottom: 24 }} className="no-print">
              <Descriptions.Item label="Customer">{viewModal.order.customer_name}</Descriptions.Item>
              <Descriptions.Item label="Phone">{viewModal.order.customer_phone}</Descriptions.Item>
              <Descriptions.Item label="Payment">
                <Tag color={paymentColors[viewModal.order.payment_method]}>
                  {paymentLabels[viewModal.order.payment_method]}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Status">
                <Tag color={statusColors[viewModal.order.status]}>
                  {statusLabels[viewModal.order.status] || viewModal.order.status?.toUpperCase()}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Created">{formatDate(viewModal.order.created_at)}</Descriptions.Item>
              {viewModal.order.completed_at && (
                <Descriptions.Item label="Completed">{formatDate(viewModal.order.completed_at)}</Descriptions.Item>
              )}
              {viewModal.order.notes && (
                <Descriptions.Item label="Retailer Comments" span={2}>
                  <div style={{ background: '#f5f5f5', padding: '8px 12px', borderRadius: 4, width: '100%' }}>
                    <Text italic>{viewModal.order.notes}</Text>
                  </div>
                </Descriptions.Item>
              )}
            </Descriptions>

            <Table
              dataSource={viewModal.order.items}
              pagination={false}
              rowKey="id"
              size="small"
              columns={[
                {
                  title: 'Product',
                  key: 'product_name',
                  render: (_, record) => (
                    <Space>
                      {record.image ? (
                        <img
                          src={record.image}
                          alt={record.product_name}
                          style={{ width: 40, height: 40, objectFit: 'cover', borderRadius: 4 }}
                        />
                      ) : (
                        <div style={{ width: 40, height: 40, background: '#f5f5f5', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <ShoppingCartOutlined style={{ fontSize: 20, color: '#ccc' }} />
                        </div>
                      )}
                      <div>
                        <Text strong>{record.product_name}</Text>
                        <br />
                        <Text type="secondary" style={{ fontSize: 11 }}>SKU: {record.sku || 'N/A'}</Text>
                      </div>
                    </Space>
                  ),
                },
                {
                  title: 'Qty',
                  dataIndex: 'quantity',
                  key: 'quantity',
                  align: 'center',
                },
                {
                  title: 'Price',
                  dataIndex: 'unit_price',
                  key: 'unit_price',
                  render: (value: number) => `${value?.toLocaleString()} RWF`,
                  align: 'right',
                },
                {
                  title: 'Total',
                  dataIndex: 'total',
                  key: 'total',
                  render: (value: number) => <Text strong>{value?.toLocaleString()} RWF</Text>,
                  align: 'right',
                },
              ]}
              summary={() => (
                <>
                  <Table.Summary.Row>
                    <Table.Summary.Cell index={0} colSpan={3}><Text>Subtotal</Text></Table.Summary.Cell>
                    <Table.Summary.Cell index={1} align="right">
                      <Text>{viewModal.order?.subtotal?.toLocaleString()} RWF</Text>
                    </Table.Summary.Cell>
                  </Table.Summary.Row>
                  {(viewModal.order?.discount || 0) > 0 && (
                    <Table.Summary.Row>
                      <Table.Summary.Cell index={0} colSpan={3}><Text type="success">Discount</Text></Table.Summary.Cell>
                      <Table.Summary.Cell index={1} align="right">
                        <Text type="success">-{viewModal.order?.discount?.toLocaleString()} RWF</Text>
                      </Table.Summary.Cell>
                    </Table.Summary.Row>
                  )}
                  <Table.Summary.Row>
                    <Table.Summary.Cell index={0} colSpan={3}><Title level={5} style={{ margin: 0 }}>Total</Title></Table.Summary.Cell>
                    <Table.Summary.Cell index={1} align="right">
                      <Title level={5} style={{ margin: 0, color: '#0ea5e9' }}>
                        {viewModal.order?.total?.toLocaleString()} RWF
                      </Title>
                    </Table.Summary.Cell>
                  </Table.Summary.Row>
                </>
              )}
            />
          </div>
        ) : (
          <Empty description="Order not found" />
        )}
      </Modal>

      {/* Configure Order Modal */}
      <Modal
        title="Configure USSD Order Request"
        open={configureModalVisible}
        onCancel={() => setConfigureModalVisible(false)}
        okText="Save & Request Payment"
        confirmLoading={configureLoading}
        onOk={handleSubmitConfiguration}
        width={700}
      >
        <Spin spinning={configureLoading}>
          <div style={{ marginBottom: 16 }}>
            <Text strong>Select Product to Add:</Text>
            <Select
              showSearch
              placeholder="Search product..."
              style={{ width: '100%', marginTop: 8 }}
              optionFilterProp="children"
              onChange={(value) => handleAddItemToConfigure(value)}
              value={null}
            >
              {inventoryProducts.map((prod) => (
                <Select.Option key={prod.id} value={prod.id}>
                  {prod.name} ({prod.price?.toLocaleString()} RWF) - Stock: {prod.stock}
                </Select.Option>
              ))}
            </Select>
          </div>

          <Table
            dataSource={selectedItems}
            pagination={false}
            rowKey="productId"
            size="small"
            columns={[
              {
                title: 'Product',
                key: 'product',
                render: (_, record) => {
                  const product = inventoryProducts.find((p) => String(p.id) === String(record.productId));
                  return product?.name || 'Unknown Product';
                },
              },
              {
                title: 'Price',
                key: 'price',
                align: 'right',
                render: (_, record) => {
                  const product = inventoryProducts.find((p) => String(p.id) === String(record.productId));
                  return `${product?.price?.toLocaleString() || 0} RWF`;
                },
              },
              {
                title: 'Quantity',
                key: 'quantity',
                align: 'center',
                render: (_, record) => (
                  <Input
                    type="number"
                    min={1}
                    value={record.quantity}
                    onChange={(e) => handleUpdateItemQuantity(record.productId, parseInt(e.target.value) || 0)}
                    style={{ width: 80, textAlign: 'center' }}
                  />
                ),
              },
              {
                title: 'Subtotal',
                key: 'subtotal',
                align: 'right',
                render: (_, record) => {
                  const product = inventoryProducts.find((p) => String(p.id) === String(record.productId));
                  const subtotal = (product?.price || 0) * record.quantity;
                  return <Text strong>{subtotal.toLocaleString()} RWF</Text>;
                },
              },
              {
                title: 'Action',
                key: 'action',
                align: 'center',
                render: (_, record) => (
                  <Button
                    type="text"
                    danger
                    icon={<CloseOutlined />}
                    onClick={() => handleUpdateItemQuantity(record.productId, 0)}
                  />
                ),
              },
            ]}
            summary={() => {
              let total = 0;
              selectedItems.forEach((item) => {
                const product = inventoryProducts.find((p) => String(p.id) === String(item.productId));
                total += (product?.price || 0) * item.quantity;
              });
              return (
                <Table.Summary.Row>
                  <Table.Summary.Cell index={0} colSpan={3}>
                    <Text strong>Total Amount</Text>
                  </Table.Summary.Cell>
                  <Table.Summary.Cell index={1} align="right">
                    <Title level={5} style={{ margin: 0, color: '#0ea5e9' }}>
                      {total.toLocaleString()} RWF
                    </Title>
                  </Table.Summary.Cell>
                  <Table.Summary.Cell index={2} />
                </Table.Summary.Row>
              );
            }}
          />

          <div style={{ marginTop: 16 }}>
            <Text strong>Reward Wallet ID <Text type="secondary" style={{ fontSize: 12, fontWeight: 'normal' }}>(Optional — enter customer's Reward Wallet ID to route gas reward)</Text></Text>
            <Input
              style={{ marginTop: 8 }}
              placeholder="e.g. 58200077517"
              value={rewardWalletId}
              onChange={e => setRewardWalletId(e.target.value)}
              allowClear
            />
          </div>
        </Spin>
      </Modal>

      <style>{`
        .ant-table-row-pending {
          background-color: #fff7e6;
        }
        .ant-table-row-pending:hover > td {
          background-color: #fff1b8 !important;
        }
      `}</style>
    </div>
  );
};

export default OrdersPage;
